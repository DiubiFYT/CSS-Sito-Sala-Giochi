<html>
<title>Accedi - Bergamo Arcade</title>
<head>
    <link href="accedi.css" rel="stylesheet">
</head>
<body style="background: url(img/GTAslot.png); text-align:center;">
    <div class="loginbox">
    <img src="img/avatar.png" class="avatar">
        <h1>Accedi</h1>
        <form>
            <p>Username</p>
            <input type="text" name="" placeholder="Inserisci il tuo username">
            <p>Password</p>
            <input type="password" name="" placeholder="Inserisci la tua password">
            <input type="submit" name="" value="Login">
            <a href="registrazione.php">Non hai un account?</a><br>
        </form>
        
    </div>
</body>
</html>