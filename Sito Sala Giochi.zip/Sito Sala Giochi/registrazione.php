<html>
<head>
    <link rel="stylesheet" type="text/css" href="registrazione.css">
</head>
<title>Registrati - Bergamo Arcade</title>

<body style="background: url(img/GTAslot.png);"> 
    <div class="loginbox">
    <img src="img/avatar.png" class="avatar">
        <h1>Registrati</h1>
        <form>
            <p>Username</p>
            <input type="text" name="" placeholder="Inserisci il tuo username">
			<p>Email</p>
			<input type="Email" name="" placeholder="Inserisci la tua email">
			<p>Password</p>
            <input type="password" name="" placeholder="Inserisci la tua password">			
            <p>Conferma password</p>
            <input type="password" name="" placeholder="Inserisci la tua password">
			<p>Numero di telefono</p>
			<input type="Numero di telefono" name="" placeholder="Inserisci il tuo numero di telefono">		
            <input type="submit" name="" value="Login">
            <a href="accedi.php">Hai già un account?</a>
        </form>
</div>
</body>
</html>